# Dragon Brood — Forge 1.20.1 (47.x)

## Сборка .jar
1. Скачайте MDK Forge 1.20.1 (47.x) с https://files.minecraftforge.net/ и распакуйте.
2. Замените папку `src` из MDK на папку `src` из этого архива.
3. В `gradle.properties` MDK поставьте: `mod_id=dragonbrood`, `mod_name=Dragon Brood`, `mod_version=1.0.0`,
   `mod_group_id=com.dragonbrood`. (Java 17.)
4. `gradlew build` -> готовый мод в `build/libs/dragonbrood-1.0.0.jar` -> в папку `mods`.

## Как играть
- Подлетите к Эндер-дракону (Элитры + /summon minecraft:ender_dragon для теста) — появится кнопка, нажмите R (меняется в настройках управления).
- Дни 1–2: урчит живот. Дни 3–9: живот растёт, покрывается венами, внутри шевелится.
- В конце последнего дня (60 сек): падение на спину, живот ходит ходуном, сердцебиение и рёв дракона, разрыв, малыш-дракон.
- Конфиг `config/dragonbrood-common.toml`: quietDays, growthDays, laborSeconds, lethalBirth.
- Тест-команды (OP): `/dragonbrood start`, `/dragonbrood labor` (сразу за 5 сек до родов), `/dragonbrood clear`.
- Малыш — ручной летающий питомец; ПКМ — сидеть/встать; корм — плод хоруса.
