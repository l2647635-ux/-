package com.dragonbrood;

import net.minecraft.commands.Commands;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DragonBrood.MODID)
public class ServerEvents {

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase == TickEvent.Phase.END && e.side == LogicalSide.SERVER && e.player instanceof ServerPlayer sp) {
            Pregnancy.tick(sp);
        }
    }

    @SubscribeEvent
    public static void death(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp && Pregnancy.isPregnant(sp)) Pregnancy.clear(sp);
    }

    /** Во время родов прыгать нельзя. */
    @SubscribeEvent
    public static void jump(LivingEvent.LivingJumpEvent e) {
        if (e.getEntity() instanceof Player p && Pregnancy.inLabor(p)) {
            var m = p.getDeltaMovement();
            p.setDeltaMovement(m.x, 0, m.z);
        }
    }

    /** Сохраняем беременность при возврате из Энда (Clone без смерти). */
    @SubscribeEvent
    public static void clone(PlayerEvent.Clone e) {
        if (e.isWasDeath()) return;
        CompoundTag o = e.getOriginal().getPersistentData();
        if (o.getBoolean(Pregnancy.ACTIVE)) {
            CompoundTag n = e.getEntity().getPersistentData();
            n.putBoolean(Pregnancy.ACTIVE, true);
            n.putInt(Pregnancy.TICKS, o.getInt(Pregnancy.TICKS));
        }
    }

    /** Команды для теста (нужен OP): /dragonbrood start | labor | clear */
    @SubscribeEvent
    public static void commands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("dragonbrood").requires(s -> s.hasPermission(2))
                .then(Commands.literal("start").executes(c -> {
                    Pregnancy.start(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("labor").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    p.getPersistentData().putBoolean(Pregnancy.ACTIVE, true);
                    p.getPersistentData().putInt(Pregnancy.TICKS, Pregnancy.laborStart() - 100);
                    return 1;
                }))
                .then(Commands.literal("clear").executes(c -> {
                    Pregnancy.clear(c.getSource().getPlayerOrException());
                    return 1;
                })));
    }
}
