package com.dragonbrood;

import net.minecraftforge.common.ForgeConfigSpec;

public class DragonConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue QUIET_DAYS;
    public static final ForgeConfigSpec.IntValue GROWTH_DAYS;
    public static final ForgeConfigSpec.IntValue LABOR_SECONDS;
    public static final ForgeConfigSpec.BooleanValue LETHAL_BIRTH;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        QUIET_DAYS = b.comment("Дни, когда только урчит живот (1 день = 24000 тиков = 20 минут)")
                .defineInRange("quietDays", 2, 0, 100);
        GROWTH_DAYS = b.comment("Дни роста живота")
                .defineInRange("growthDays", 7, 1, 100);
        LABOR_SECONDS = b.comment("Длительность финальных родов (секунды) в конце последнего дня")
                .defineInRange("laborSeconds", 60, 10, 600);
        LETHAL_BIRTH = b.comment("true = игрок погибает при родах, false = остаётся с 1 сердцем")
                .define("lethalBirth", false);
        SPEC = b.build();
    }
}
