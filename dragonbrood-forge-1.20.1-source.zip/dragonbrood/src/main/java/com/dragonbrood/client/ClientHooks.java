package com.dragonbrood.client;

import com.dragonbrood.ClientState;
import net.minecraft.client.Minecraft;

public class ClientHooks {
    public static void sync(int id, int amp) {
        var level = Minecraft.getInstance().level;
        if (level != null) ClientState.set(id, amp, level.getGameTime());
    }
}
