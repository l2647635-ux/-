package com.dragonbrood.client;

import com.dragonbrood.DragonBrood;
import com.dragonbrood.entity.BabyEnderDragon;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class BabyDragonModel extends EntityModel<BabyEnderDragon> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(DragonBrood.MODID, "baby_ender_dragon"), "main");

    private final ModelPart root, head, wingL, wingR, tail;

    public BabyDragonModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.wingL = root.getChild("wingL");
        this.wingR = root.getChild("wingR");
        this.tail = root.getChild("tail");
    }

    /** Текстура 64x64: всё тёмное, глаза — пурпурный квадрат в (48,56). */
    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-4, -3, -6, 8, 6, 12), PartPose.offset(0, 17, 0));
        r.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 20).addBox(-3, -2.5f, -6, 6, 5, 6)
                .texOffs(48, 56).addBox(-2.5f, -1.5f, -6.4f, 1, 1, 1)
                .texOffs(48, 56).addBox(1.5f, -1.5f, -6.4f, 1, 1, 1)
                .texOffs(30, 50).addBox(-2.5f, -4.5f, -2, 1, 2, 1)
                .texOffs(30, 50).addBox(1.5f, -4.5f, -2, 1, 2, 1),
                PartPose.offset(0, 15.5f, -6));
        r.addOrReplaceChild("wingL", CubeListBuilder.create().texOffs(0, 32).addBox(0, -0.5f, -4, 14, 1, 8), PartPose.offset(3, 14.5f, -1));
        r.addOrReplaceChild("wingR", CubeListBuilder.create().texOffs(0, 32).addBox(-14, -0.5f, -4, 14, 1, 8), PartPose.offset(-3, 14.5f, -1));
        r.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(0, 44).addBox(-1.5f, -1.5f, 0, 3, 3, 10), PartPose.offset(0, 17, 6));
        r.addOrReplaceChild("legL", CubeListBuilder.create().texOffs(30, 44).addBox(-1, 0, -1, 2, 3, 2), PartPose.offset(2.5f, 20, 2));
        r.addOrReplaceChild("legR", CubeListBuilder.create().texOffs(30, 44).addBox(-1, 0, -1, 2, 3, 2), PartPose.offset(-2.5f, 20, 2));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(BabyEnderDragon e, float limbSwing, float limbSwingAmount, float age, float netHeadYaw, float headPitch) {
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        head.xRot = headPitch * Mth.DEG_TO_RAD;
        float flap = e.onGround() ? 0.1f : Mth.sin(age * 0.9f) * 0.7f;
        wingL.zRot = flap;
        wingR.zRot = -flap;
        tail.yRot = Mth.sin(age * 0.2f) * 0.3f;
        tail.xRot = 0.15f;
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
