package com.dragonbrood.client;

import com.dragonbrood.DragonBrood;
import com.dragonbrood.entity.BabyEnderDragon;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class BabyEnderDragonRenderer extends MobRenderer<BabyEnderDragon, BabyDragonModel> {
    private static final ResourceLocation TEX = new ResourceLocation(DragonBrood.MODID, "textures/entity/baby_ender_dragon.png");

    public BabyEnderDragonRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new BabyDragonModel(ctx.bakeLayer(BabyDragonModel.LAYER)), 0.3f);
    }

    @Override
    public ResourceLocation getTextureLocation(BabyEnderDragon e) { return TEX; }
}
