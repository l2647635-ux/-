package com.dragonbrood.client;

import com.dragonbrood.ClientState;
import com.dragonbrood.DragonBrood;
import com.dragonbrood.Pregnancy;
import com.dragonbrood.net.ImpregnatePacket;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DragonBrood.MODID, value = Dist.CLIENT)
public class ClientEvents {
    public static boolean nearDragon = false;

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();

        while (ClientModEvents.KEY.consumeClick()) {
            if (nearDragon && mc.player != null && ClientState.amp(mc.player) < 0) {
                DragonBrood.CHANNEL.sendToServer(new ImpregnatePacket());
                nearDragon = false;
            }
        }
        if (mc.player == null || mc.level == null || mc.screen != null) { nearDragon = false; return; }
        if (mc.player.tickCount % 5 == 0) {
            nearDragon = ClientState.amp(mc.player) < 0 && Pregnancy.nearDragon(mc.player);
        }
    }

    /** Во время родов игрок лежит на спине. */
    @SubscribeEvent
    public static void renderPre(RenderPlayerEvent.Pre e) {
        Player p = e.getEntity();
        float f = ClientState.laborProgress(p, e.getPartialTick());
        if (f < 0) return;
        var ps = e.getPoseStack();
        float yaw = Mth.rotLerp(e.getPartialTick(), p.yBodyRotO, p.yBodyRot);
        ps.pushPose();
        ps.translate(0, 0.15 * f, 0);
        ps.mulPose(Axis.YP.rotationDegrees(180f - yaw));
        ps.mulPose(Axis.XP.rotationDegrees(90f * f));   // если падает лицом вниз — поменяйте знак на -90f
        ps.mulPose(Axis.YP.rotationDegrees(-(180f - yaw)));
    }

    @SubscribeEvent
    public static void renderPost(RenderPlayerEvent.Post e) {
        if (ClientState.laborProgress(e.getEntity(), e.getPartialTick()) >= 0) e.getPoseStack().popPose();
    }

    /** Камера от первого лица запрокидывается вверх. */
    @SubscribeEvent
    public static void camera(ViewportEvent.ComputeCameraAngles e) {
        Entity cam = e.getCamera().getEntity();
        if (!(cam instanceof Player p)) return;
        float f = ClientState.laborProgress(p, (float) e.getPartialTick());
        if (f < 0) return;
        e.setPitch(Mth.lerp(f, e.getPitch(), -75f));
    }
}
