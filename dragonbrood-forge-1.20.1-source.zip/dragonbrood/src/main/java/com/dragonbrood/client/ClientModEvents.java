package com.dragonbrood.client;

import com.dragonbrood.DragonBrood;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DragonBrood.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    public static final KeyMapping KEY = new KeyMapping("key.dragonbrood.interact", InputConstants.KEY_R, "key.categories.dragonbrood");

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) { e.register(KEY); }

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(BabyDragonModel.LAYER, BabyDragonModel::createLayer);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(DragonBrood.BABY_DRAGON.get(), BabyEnderDragonRenderer::new);
    }

    @SubscribeEvent
    public static void addLayers(EntityRenderersEvent.AddLayers e) {
        for (String skin : new String[]{"default", "slim"}) {
            PlayerRenderer r = e.getSkin(skin);
            if (r != null) r.addLayer(new BellyLayer(r));
        }
    }

    /** Кнопка-подсказка у дракона. */
    @SubscribeEvent
    public static void overlay(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("dragon_prompt", (gui, g, partial, w, h) -> {
            Minecraft mc = Minecraft.getInstance();
            if (!ClientEvents.nearDragon || mc.options.hideGui) return;
            Component txt = Component.translatable("gui.dragonbrood.prompt", KEY.getTranslatedKeyMessage());
            Font font = mc.font;
            int tw = font.width(txt) + 20, x = w / 2 - tw / 2, y = h / 2 + 30;
            g.fill(x, y, x + tw, y + 22, 0xCC000000);
            g.renderOutline(x, y, tw, 22, 0xFFAA00FF);
            g.drawCenteredString(font, txt, w / 2, y + 7, 0xFFFFFF);
        });
    }
}
