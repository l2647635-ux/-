package com.dragonbrood.client;

import com.dragonbrood.ClientState;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import java.util.Random;

/** Рисует растущий живот (кожа игрока) + слой чёрных вен, который становится гуще с прогрессом. */
public class BellyLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {

    private static final int[] VEIN_COUNTS = {6, 14, 26, 42, 62, 88};
    private static final ResourceLocation[] VEIN_TEX = new ResourceLocation[VEIN_COUNTS.length];

    public BellyLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    private static ResourceLocation vein(int level) {
        if (VEIN_TEX[level] == null) {
            NativeImage img = new NativeImage(64, 64, true);
            Random rnd = new Random(1337); // тот же seed: вены нового уровня включают старые
            for (int i = 0; i < VEIN_COUNTS[level]; i++) {
                float x = rnd.nextInt(64), y = rnd.nextInt(64), ang = rnd.nextFloat() * 6.2831f;
                int len = 10 + rnd.nextInt(26);
                for (int s = 0; s < len; s++) {
                    ang += (rnd.nextFloat() - 0.5f) * 0.9f;
                    x += Mth.cos(ang);
                    y += Mth.sin(ang);
                    int px = Math.floorMod((int) x, 64), py = Math.floorMod((int) y, 64);
                    img.setPixelRGBA(px, py, 0xFF1A0512); // ABGR
                    img.setPixelRGBA(Math.floorMod(px + 1, 64), py, 0xFF1A0512);
                }
            }
            VEIN_TEX[level] = Minecraft.getInstance().getTextureManager()
                    .register("dragonbrood_veins_" + level, new DynamicTexture(img));
        }
        return VEIN_TEX[level];
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer p,
                       float limbSwing, float limbSwingAmount, float partial, float age, float netYaw, float pitch) {
        int amp = ClientState.amp(p);
        if (amp <= 0) return;
        float g = Math.min(amp, 99) / 99f;
        if (g < 0.01f) return;
        boolean labor = amp >= 100;

        float t = p.tickCount + partial;
        float wob;
        if (labor) {
            wob = 1f + 0.10f * Mth.sin(t * 1.7f) + 0.05f * Mth.sin(t * 4.3f); // ходит ходуном
        } else {
            float k = Math.max(0f, Mth.sin(t * 0.09f) * Mth.sin(t * 0.037f));  // редкие пинки изнутри
            wob = 1f + 0.015f * Mth.sin(t * 0.3f) + 0.12f * k * k * k * k;
        }

        float w = (5.5f + g * 3.2f) * wob, h = (4.5f + g * 4.5f) * wob, d = (0.4f + g * 7.0f) * wob;
        float cy = 8.2f;
        float x0 = -w / 2, x1 = w / 2, y0 = cy - h / 2, y1 = cy + h / 2, z1 = -1.9f, z0 = -2f - d;

        float tr = 1f, tg = labor ? 0.8f : 0.93f, tb = labor ? 0.8f : 0.93f;

        ps.pushPose();
        getParentModel().body.translateAndRotate(ps);

        // Основа: кусочек кожи с живота скина игрока
        VertexConsumer base = buf.getBuffer(RenderType.entityCutoutNoCull(p.getSkinTextureLocation()));
        box(ps, base, x0, y0, z0, x1, y1, z1, 22 / 64f, 26 / 64f, 26 / 64f, 30 / 64f, light, tr, tg, tb, 1f);

        // Вены
        if (g > 0.04f) {
            int lvl = Math.min(VEIN_COUNTS.length - 1, (int) (g * VEIN_COUNTS.length));
            VertexConsumer vv = buf.getBuffer(RenderType.entityTranslucent(vein(lvl)));
            float e = 0.15f;
            box(ps, vv, x0 - e, y0 - e, z0 - e, x1 + e, y1 + e, z1, 0f, 0f, 1f, 1f, light, 1f, 1f, 1f, 0.95f);
        }
        ps.popPose();
    }

    // ---- простейший рендер параллелепипеда (координаты в пикселях модели) ----

    private static void box(PoseStack ps, VertexConsumer vc, float x0, float y0, float z0, float x1, float y1, float z1,
                            float u0, float v0, float u1, float v1, int light, float r, float g, float b, float a) {
        PoseStack.Pose pose = ps.last();
        quad(vc, pose, light, r, g, b, a, 0, 0, -1, u0, v0, u1, v1, x0, y1, z0, x1, y1, z0, x1, y0, z0, x0, y0, z0); // перед
        quad(vc, pose, light, r, g, b, a, 0, 0, 1, u0, v0, u1, v1, x1, y1, z1, x0, y1, z1, x0, y0, z1, x1, y0, z1);   // зад
        quad(vc, pose, light, r, g, b, a, -1, 0, 0, u0, v0, u1, v1, x0, y1, z1, x0, y1, z0, x0, y0, z0, x0, y0, z1); // лево
        quad(vc, pose, light, r, g, b, a, 1, 0, 0, u0, v0, u1, v1, x1, y1, z0, x1, y1, z1, x1, y0, z1, x1, y0, z0);  // право
        quad(vc, pose, light, r, g, b, a, 0, -1, 0, u0, v0, u1, v1, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1); // верх
        quad(vc, pose, light, r, g, b, a, 0, 1, 0, u0, v0, u1, v1, x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0);  // низ
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose pose, int light, float r, float g, float b, float a,
                             float nx, float ny, float nz, float u0, float v0, float u1, float v1, float... p) {
        float[][] uv = {{u0, v0}, {u1, v0}, {u1, v1}, {u0, v1}};
        for (int i = 0; i < 4; i++) {
            vc.vertex(pose.pose(), p[i * 3] / 16f, p[i * 3 + 1] / 16f, p[i * 3 + 2] / 16f)
                    .color(r, g, b, a).uv(uv[i][0], uv[i][1])
                    .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light)
                    .normal(pose.normal(), nx, ny, nz).endVertex();
        }
    }
}
