package com.dragonbrood;

import com.dragonbrood.entity.BabyEnderDragon;
import com.dragonbrood.net.ImpregnatePacket;
import com.dragonbrood.net.SyncPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(DragonBrood.MODID)
public class DragonBrood {
    public static final String MODID = "dragonbrood";

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);

    public static final RegistryObject<EntityType<BabyEnderDragon>> BABY_DRAGON = ENTITIES.register("baby_ender_dragon",
            () -> EntityType.Builder.of(BabyEnderDragon::new, MobCategory.CREATURE)
                    .sized(0.7f, 0.6f).clientTrackingRange(8).build(MODID + ":baby_ender_dragon"));

    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public DragonBrood() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        bus.addListener(this::commonSetup);
        bus.addListener(this::attributes);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, DragonConfig.SPEC);
    }

    private void commonSetup(FMLCommonSetupEvent e) {
        CHANNEL.registerMessage(0, ImpregnatePacket.class, ImpregnatePacket::encode, ImpregnatePacket::decode, ImpregnatePacket::handle);
        CHANNEL.registerMessage(1, SyncPacket.class, SyncPacket::encode, SyncPacket::decode, SyncPacket::handle);
    }

    private void attributes(EntityAttributeCreationEvent e) {
        e.put(BABY_DRAGON.get(), BabyEnderDragon.createAttributes().build());
    }
}
