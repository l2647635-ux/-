package com.dragonbrood;

import com.dragonbrood.entity.BabyEnderDragon;
import com.dragonbrood.net.SyncPacket;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.enderdragon.EnderDragonPart;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

import java.util.List;

/** Вся серверная логика "вынашивания". Данные хранятся в persistent data игрока. */
public final class Pregnancy {
    public static final String ACTIVE = "dragonbrood_active";
    public static final String TICKS = "dragonbrood_ticks";

    public static int quiet()      { return DragonConfig.QUIET_DAYS.get() * 24000; }
    public static int total()      { return (DragonConfig.QUIET_DAYS.get() + DragonConfig.GROWTH_DAYS.get()) * 24000; }
    public static int laborStart() { return total() - DragonConfig.LABOR_SECONDS.get() * 20; }

    public static boolean isPregnant(Player p) { return p.getPersistentData().getBoolean(ACTIVE); }

    /** Работает и на клиенте (через ClientState), и на сервере. */
    public static boolean inLabor(Player p) {
        if (p.level().isClientSide) return ClientState.amp(p) >= 100;
        CompoundTag d = p.getPersistentData();
        return d.getBoolean(ACTIVE) && d.getInt(TICKS) >= laborStart();
    }

    public static boolean nearDragon(Player p) {
        if (p.isSpectator()) return false;
        List<EnderDragon> list = p.level().getEntitiesOfClass(EnderDragon.class, p.getBoundingBox().inflate(48));
        for (EnderDragon d : list)
            for (EnderDragonPart part : d.getSubEntities())
                if (part.getBoundingBox().inflate(3.0).intersects(p.getBoundingBox())) return true;
        return false;
    }

    public static void start(ServerPlayer p) {
        CompoundTag d = p.getPersistentData();
        d.putBoolean(ACTIVE, true);
        d.putInt(TICKS, 0);
        ServerLevel l = p.serverLevel();
        l.sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 80, 0.5, 0.8, 0.5, 0.6);
        play(p, SoundEvents.ENDER_DRAGON_GROWL, 1.0f, 0.8f);
        p.displayClientMessage(Component.translatable("msg.dragonbrood.started"), true);
        sync(p, 0);
    }

    public static void clear(ServerPlayer p) {
        CompoundTag d = p.getPersistentData();
        d.putBoolean(ACTIVE, false);
        d.putInt(TICKS, 0);
        sync(p, -1);
    }

    private static int amp(int t) {
        int q = quiet(), ls = laborStart();
        if (t >= ls) return 100;
        if (t < q) return 0;
        return Math.min(99, (int) (99f * (t - q) / (ls - q)));
    }

    private static void sync(ServerPlayer p, int amp) {
        DragonBrood.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> p), new SyncPacket(p.getId(), amp));
    }

    private static void play(ServerPlayer p, SoundEvent s, float vol, float pitch) {
        p.level().playSound(null, p.getX(), p.getY() + 0.8, p.getZ(), s, SoundSource.PLAYERS, vol, pitch);
    }

    /** Урчание живота: низкий рёв рэйвена. Замените на свой .ogg через sounds.json при желании. */
    private static void growl(ServerPlayer p, float vol) {
        play(p, SoundEvents.RAVAGER_AMBIENT, vol, 0.45f + p.getRandom().nextFloat() * 0.25f);
    }

    private static void kick(ServerPlayer p) {
        play(p, SoundEvents.SLIME_SQUISH, 0.8f, 0.5f + p.getRandom().nextFloat() * 0.3f);
    }

    public static void tick(ServerPlayer p) {
        CompoundTag d = p.getPersistentData();
        if (!d.getBoolean(ACTIVE)) return;

        int t = d.getInt(TICKS) + 1;
        d.putInt(TICKS, t);
        int q = quiet(), ls = laborStart(), total = total();
        RandomSource r = p.getRandom();

        if (t % 20 == 1) sync(p, amp(t));

        if (t < q) {
            // Первые дни: громко урчит живот
            if (r.nextInt(700) == 0) growl(p, 1.2f);
        } else if (t < ls) {
            // Рост: урчание + шевеления внутри
            if (r.nextInt(900) == 0) growl(p, 1.0f);
            if (r.nextInt(450) == 0) kick(p);
            if (r.nextInt(2400) == 0) play(p, SoundEvents.ENDER_DRAGON_GROWL, 0.35f, 0.4f);
        } else {
            // Роды
            int lt = t - ls;
            if (lt % 10 == 0) {
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 9, false, false, false));
                p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 60, 0, false, false, false));
            }
            p.setSprinting(false);
            if (lt % 18 == 0) growl(p, 1.8f);
            if (lt % 22 == 0) play(p, SoundEvents.WARDEN_HEARTBEAT, 1.6f, 0.8f + 0.4f * lt / Math.max(1, total - ls));
            if (lt % 70 == 0) play(p, SoundEvents.ENDER_DRAGON_GROWL, 0.7f, 0.35f);
            if (lt % 35 == 17) kick(p);
            if (lt % 100 == 50 && p.getHealth() > 4f) p.hurt(p.damageSources().generic(), 1.0f);
            if (t >= total) birth(p);
        }
    }

    private static void birth(ServerPlayer p) {
        ServerLevel l = p.serverLevel();
        double x = p.getX(), y = p.getY() + 0.4, z = p.getZ();

        l.sendParticles(new DustParticleOptions(new Vector3f(0.6f, 0.0f, 0.0f), 2.0f), x, y + 0.3, z, 160, 0.4, 0.3, 0.4, 0.3);
        l.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.defaultBlockState()), x, y + 0.3, z, 70, 0.3, 0.2, 0.3, 0.15);
        play(p, SoundEvents.SLIME_SQUISH, 1.6f, 0.5f);
        play(p, SoundEvents.PLAYER_HURT, 1.2f, 0.6f);
        play(p, SoundEvents.GENERIC_EXPLODE, 0.35f, 1.7f);
        play(p, SoundEvents.ENDER_DRAGON_GROWL, 1.0f, 1.9f);

        BabyEnderDragon baby = DragonBrood.BABY_DRAGON.get().create(l);
        if (baby != null) {
            baby.moveTo(x, y + 0.3, z, p.getYRot(), 0);
            baby.tame(p);
            l.addFreshEntity(baby);
        }

        clear(p);
        p.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
        p.removeEffect(MobEffects.CONFUSION);

        if (DragonConfig.LETHAL_BIRTH.get()) {
            p.hurt(l.damageSources().generic(), Float.MAX_VALUE);
        } else {
            p.setHealth(Math.min(p.getHealth(), 2.0f));
            p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 1200, 1));
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 600, 1));
        }
    }
}
