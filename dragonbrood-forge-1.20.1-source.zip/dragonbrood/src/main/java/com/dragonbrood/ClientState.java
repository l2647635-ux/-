package com.dragonbrood;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

import java.util.HashMap;
import java.util.Map;

/** Клиентская копия состояния беременности (приходит пакетом). Без импортов клиентских классов. */
public final class ClientState {
    // id -> {amp, lastUpdateGameTime, laborSinceGameTime}
    private static final Map<Integer, long[]> MAP = new HashMap<>();

    public static void set(int id, int amp, long now) {
        if (amp < 0) { MAP.remove(id); return; }
        long[] old = MAP.get(id);
        long since = amp >= 100 ? ((old != null && old[0] >= 100) ? old[2] : now) : 0;
        MAP.put(id, new long[]{amp, now, since});
    }

    /** -1 = не беременна; 0..99 = рост живота; 100 = роды. */
    public static int amp(Entity e) {
        long[] a = MAP.get(e.getId());
        if (a == null) return -1;
        if (e.level().getGameTime() - a[1] > 100) return -1;
        return (int) a[0];
    }

    /** -1 = не рожает, иначе 0..1 (падение на спину). */
    public static float laborProgress(Entity e, float partial) {
        long[] a = MAP.get(e.getId());
        if (a == null || a[0] < 100 || e.level().getGameTime() - a[1] > 100) return -1f;
        float t = (e.level().getGameTime() + partial - a[2]) / 12f;
        t = Mth.clamp(t, 0f, 1f);
        return 1f - (1f - t) * (1f - t);
    }
}
