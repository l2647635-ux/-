package com.dragonbrood.net;

import com.dragonbrood.Pregnancy;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Клиент -> сервер: игрок нажал кнопку рядом с драконом. */
public class ImpregnatePacket {
    public void encode(FriendlyByteBuf buf) {}

    public static ImpregnatePacket decode(FriendlyByteBuf buf) { return new ImpregnatePacket(); }

    public static void handle(ImpregnatePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer p = ctx.get().getSender();
            if (p == null || Pregnancy.isPregnant(p) || !Pregnancy.nearDragon(p)) return;
            Pregnancy.start(p);
        });
        ctx.get().setPacketHandled(true);
    }
}
