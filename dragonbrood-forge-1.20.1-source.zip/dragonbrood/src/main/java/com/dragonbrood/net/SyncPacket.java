package com.dragonbrood.net;

import com.dragonbrood.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Сервер -> клиенты: стадия беременности игрока (-1 нет, 0..99 рост, 100 роды). */
public class SyncPacket {
    public final int id;
    public final int amp;

    public SyncPacket(int id, int amp) { this.id = id; this.amp = amp; }

    public void encode(FriendlyByteBuf buf) { buf.writeVarInt(id); buf.writeVarInt(amp + 1); }

    public static SyncPacket decode(FriendlyByteBuf buf) { return new SyncPacket(buf.readVarInt(), buf.readVarInt() - 1); }

    public static void handle(SyncPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.sync(m.id, m.amp)));
        ctx.get().setPacketHandled(true);
    }
}
